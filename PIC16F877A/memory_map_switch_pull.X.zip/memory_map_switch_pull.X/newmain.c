/*
 * File:   newmain.c
 * Author: vignesh-camkie
 *
 * Created on 5 June, 2025, 11:46 AM
 */

// PIC16F877A Configuration Bit Settings
#pragma config FOSC = EXTRC     // Oscillator Selection bits (RC oscillator)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config BOREN = OFF      // Brown-out Reset Enable bit (BOR disabled)
#pragma config LVP = OFF        // Low-Voltage (Single-Supply) In-Circuit Serial Programming Enable bit (RB3 is digital I/O, HV on MCLR must be used for programming)
#pragma config CPD = OFF        // Data EEPROM Memory Code Protection bit (Data EEPROM code protection off)
#pragma config WRT = OFF        // Flash Program Memory Write Enable bits (Write protection off; all program memory may be written to by EECON control)
#pragma config CP = OFF         // Flash Program Memory Code Protection bit (Code protection off)

#include <xc.h>
#define _XTAL_FREQ 6000000

void main()
{
    // Memory mapping for registers
    unsigned char *trisb_reg = (unsigned char *)0x86;     // TRISB address
    unsigned char *trisc_reg = (unsigned char *)0x87;     // TRISC address
    unsigned char *portb_reg = (unsigned char *)0x06;     // PORTB address
    unsigned char *portc_reg = (unsigned char *)0x07;     // PORTC address
    unsigned char *option_reg = (unsigned char *)0x81;    // OPTION_REG address
    
    *option_reg = 0x7F;      // 0111 1111 Bit 7=>0 to enable PORTB internal PULL UP 
    *trisb_reg = 0xF0;       // 1111 0000  PORTB Direction => RB4 to RB7 as input
    *trisc_reg = 0xBD;       // 1011 1101  RC1 & RC6 output for LED
    *portb_reg = 0x00;       // 0000 0000
    *portc_reg = 0x00;       // 0000 0000
    
    unsigned char value;
    
    while(1)
    {
        value = *portb_reg;
        
        switch(value)
        {
            case 0xE0:  // RB4 pressed (1110 0000)
                *portc_reg = 0x02;  // RC1 =ON, RC6 = OFF
                break;
                
            case 0xD0:  // RB5 pressed (1101 0000)
                *portc_reg = 0x40;  // RC1 =OFF, RC6 = ON
                break;
                
            case 0xB0:  // RB6 pressed (1011 0000)
                *portc_reg = 0x42;  // RC1 =ON, RC6 = ON
                break;
                
            case 0x70:  // RB7 pressed (0111 0000)
                *portc_reg = 0x00;  // RC1 =OFF, RC6 = OFF
                break;

            default:
                *portc_reg = 0x00;
                break;
        }
    }
}
