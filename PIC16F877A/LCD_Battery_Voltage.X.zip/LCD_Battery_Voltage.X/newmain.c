
// PIC16F877A Configuration Bit Settings

// 'C' source line config statements

// CONFIG
#pragma config FOSC = EXTRC     // Oscillator Selection bits (RC oscillator)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config BOREN = OFF      // Brown-out Reset Enable bit (BOR disabled)
#pragma config LVP = OFF        // Low-Voltage (Single-Supply) In-Circuit Serial Programming Enable bit (RB3 is digital I/O, HV on MCLR must be used for programming)
#pragma config CPD = OFF        // Data EEPROM Memory Code Protection bit (Data EEPROM code protection off)
#pragma config WRT = OFF        // Flash Program Memory Write Enable bits (Write protection off; all program memory may be written to by EECON control)
#pragma config CP = OFF         // Flash Program Memory Code Protection bit (Code protection off)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#include <xc.h>
#define _XTAL_FREQ 6000000 // 6MHz 

// Function Declarations

void Lcd_Data(unsigned char);           // Lcd_Data function with argument unsigned char (0-255) and no return type
void Lcd_Command(unsigned char);        // Lcd_Command function with argument unsigned char (0-255) and no return type
void Lcdoutput(float);           // Lcdoutput function with argument float and no return type
void keyscane(void);                    // keyscane function with no argument and return type
void init(void);                        // init function with no argument and return type

// Global Variables
unsigned char top_line[16] = "BAT VOLT=     V"; // unsigned char array to store 16 elements including spaces and null terminator '\0'

// unsigned char arrays to print LOW,MED,HIGH on Line 2
unsigned char bat_low[16] = "BAT LOW        ";  
unsigned char bat_med[16] = "BAT MEDIUM     "; 
unsigned char bat_high[16] = "BAT HIGH       ";  
unsigned int temp;  
unsigned char x,value,d1,d2,d3;  // unsigned char variables x (for loop), value (0-255)
float volt = 17.5;     // float variable volt

void main()            // call main function with no argument and return type 
{
    init();            // call init function with no argument
    while(1)           // while loop runs forever
    {
        keyscane();    // calls keyscane function with no arguments 
    }
}

void init()
{
    TRISC = 0x00;    // PORTC as output
    TRISD = 0x00;    // PORTD as output
    TRISB = 0xF0;    // RB4-RB7 as inputs, RB0-RB3 as outputs
    OPTION_REG &= 0x7F;  // OPTION REGISTER Internal Pull Up Register on PORTB / bit 7 - 0 Enable, 1 Disable
    
    Lcd_Command(0x30);
    __delay_ms(100);
    Lcd_Command(0x30);
    __delay_ms(100);
    Lcd_Command(0x38);  // 8-bit mode, 2 lines
    __delay_ms(100);
    Lcd_Command(0x06);  // Cursor increment
    __delay_ms(100);
    Lcd_Command(0x0C);  // Display ON, cursor OFF
    __delay_ms(100);
    Lcd_Command(0x01);  // Clear display
    __delay_ms(100);
}

void keyscane()         // keyscane function definition with no argument and return type
{
    value = PORTB & 0xF0;  // Mask = 0xF0 with PORTB to get only RB4 to RB7 and keep RB0-RB3 to 0, to match the switch case 
    switch(value)          // enters switch case if value matches any 
    {
        case 0xE0:                      // If RB4 is Pressed, 0xE0 = 1110 0000
            volt = 17.5;                // 17.5 is stored in volt variable
            Lcd_Command(0x80);          // Set the LCD Address to 0x80 position line 1 in LCD
            for(x = 0; x < 16; x++)     // for loop to print "BAT VOLT=     V" form array 
            {    
                Lcd_Data(top_line[x]);
            }
            Lcdoutput(volt);            // calls Lcdoutput function with volt as argument
            Lcd_Command(0xC0);          // Set the LCD Address to 0xC0 position Line 2 in LCD
            for(x = 0; x < 16; x++)     // for loop to print "BAT MEDIUM" for array
            {    
                Lcd_Data(bat_med[x]);
            }   
            break;

        case 0xD0:                      // If RB5 is Pressed, 0xD0 = 1101 0000
            if(volt < 22.5)  
                volt += 0.1;
            Lcd_Command(0x80);          // Set the LCD Address to 0x80 position line 1 in LCD
            for(x = 0; x < 16; x++)     // for loop to print "BAT VOLT=     V" form array 
            {
                Lcd_Data(top_line[x]);
            }
            Lcdoutput(volt);            // calls Lcdoutput function with volt as argument
            Lcd_Command(0xC0);          // Set the LCD Address to 0xC0 position Line 2 in LCD
            
            // checking coonditions
            if(volt <= 17.5)            // checks if volt is less than or equal to 17.5, if TRUE, prints BAT LOW IN LINE 2
                for(x = 0; x < 16; x++)     
                {
                    Lcd_Data(bat_low[x]);
                }
            else if(volt <= 20.5)       // checks else if volt is less than or equal to 20.5, if TRUE, prints BAT MED IN LINE 2
                for(x = 0; x < 16; x++) 
                {
                    Lcd_Data(bat_med[x]);
                }
            else
                for(x = 0; x < 16; x++)     // else condition works if any condition is not satisfied
                {
                    Lcd_Data(bat_high[x]);  
                }
            break;

        case 0xB0:                      // If RB6 is Pressed, 0xB0 = 1011 0000
            if(volt > 15.5)                     // checks if volt is greater than 15.5
                volt -= 0.1;                    // decrements volt 0.1 if condition true
            
            Lcd_Command(0x80);                  // Set the LCD Address to 0x80 position line 1 in LCD
            for(x = 0; x < 16; x++)             // for loop to print "BAT VOLT=     V" form array
                Lcd_Data(top_line[x]);          // sends each character of top_line to LCD
            Lcdoutput(volt);                    // calls Lcdoutput function with volt as argument

            Lcd_Command(0xC0);                  // Set the LCD Address to 0xC0 position Line 2 in LCD
            if(volt <= 17.5)                    // checks if volt is less than or equal to 17.5
                for(x = 0; x < 16; x++)         // if true prints "BAT LOW" on line 2
                    Lcd_Data(bat_low[x]);
            else if(volt <= 20.5)               // checks else if volt is less than or equal to 20.5
                for(x = 0; x < 16; x++)         // if true, prints "BAT MEDIUM" on line 2
                    Lcd_Data(bat_med[x]);
            else                                // else condition if above conditions are false
                for(x = 0; x < 16; x++)         // prints "BAT HIGH" on line 2
                    Lcd_Data(bat_high[x]);
            break;

        case 0x70:                              // If RB7 is Pressed, 0x70 = 0111 0000
            volt = 17.6;                        // resets volt to 17.6
            
            Lcd_Command(0x80);                  // Set the LCD Address to 0x80 position line 1 in LCD
            for(x = 0; x < 16; x++)             // for loop to print "BAT VOLT=     V" form array
                Lcd_Data(top_line[x]);          // sends each character of top_line to LCD
            Lcdoutput(volt);                    // calls Lcdoutput function with volt as argument
            
            Lcd_Command(0xC0);                  // Set the LCD Address to 0xC0 position Line 2 in LCD
            for(x = 0; x < 16; x++)             // for loop to print "BAT MEDIUM" on line 2
                Lcd_Data(bat_med[x]);           // sends each character of bat_med to LCD
            break;
    }
}

void Lcd_Command(unsigned char i)           // Lcd_Command function definition with unsigned char parameter i and no return type
{
    PORTC &= ~0x08;    // RS = 0 (command)
    PORTD = i;         // store value of i in PORTD
    PORTC |= 0x01;     // EN = 1
    __delay_ms(100);   // delay 100 ms
    PORTC &= ~0x01;    // EN = 0
    __delay_ms(100);   // delay 100 ms
}

void Lcd_Data(unsigned char i)          // Lcd_Data function definition with unsigned char parameter i and no return type
{
    PORTC |= 0x08;     // RS = 1 (data)
    PORTD = i;         // store value of i in PORTD
    PORTC |= 0x01;     // EN = 1
    __delay_ms(100);     // delay 100 ms
    PORTC &= ~0x01;    // EN = 0
    __delay_ms(100);   // delay 100 ms
}

void Lcdoutput(float voltage)           // Lcdoutput function definition with float parameter voltage and no return type
{
    temp = (unsigned int)(voltage * 10);  // convert float to integer  17.5 x 10 = 175 then store in temp variable
    d3 = (unsigned char)(temp / 100);     // 175/100 = 1 then store in d3
    d2 = (unsigned char)((temp % 100) / 10);  // (175 % 100) = 75,  75 / 10 = 7 , 7 is stored in d2
    d1 = (unsigned char)(temp % 10);    // 175 % 10 = 5, then 5 is stored in d1
    
    Lcd_Command(0x89);                  // Set Address 0x89 next to "BAT VOLT="
    Lcd_Data(0x30 + d3);                // Send  ASCII (0x30 = '0')
    Lcd_Data(0x30 + d2);                // Send units digit ASCII
    Lcd_Data('.');                      // Send decimal point .
    Lcd_Data(0x30 + d1);                // Send tenths digit ASCII
}