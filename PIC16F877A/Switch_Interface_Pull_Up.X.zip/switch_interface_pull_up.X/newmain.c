/*
 * File:   newmain.c
 * Author: vignesh-camkie
 *
 * Created on 25 February, 2025, 11:46 PM
 */

// PIC16F877A Configuration Bit Settings

// 'C' source line config statements

// CONFIG
#pragma config FOSC = EXTRC     // Oscillator Selection bits (RC oscillator)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config BOREN = OFF      // Brown-out Reset Enable bit (BOR disabled)
#pragma config LVP = OFF        // Low-Voltage (Single-Supply) In-Circuit Serial Programming Enable bit (RB3 is digital I/O, HV on MCLR must be used for programming)
#pragma config CPD = OFF        // Data EEPROM Memory Code Protection bit (Data EEPROM code protection off)
#pragma config WRT = OFF        // Flash Program Memory Write Enable bits (Write protection off; all program memory may be written to by EECON control)
#pragma config CP = OFF         // Flash Program Memory Code Protection bit (Code protection off)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#include <xc.h>
#define _XTAL_FREQ 6000000

unsigned char value;
void main()
{
    TRISC = 0x0F;  // RC0 to RC3 as input 0000 1111 And RC4 TO RC7 OUTPUT
    TRISD = 0x00;  // RD0-RD7 is set as output - but we use only RD3 & RD5 for Led
    
    PORTC = 0x00;  // 0000 0000
    PORTD = 0x00;  // 0000 0000
    
    while(1)
    {
        value = PORTC; 
        
        switch(value)   
        {
            case 0x0E:  // if RC0 is pressed = 1110 0000  - RC0 goes from pull up high 1 to low 0
                PORTD = 0x20;  // 0010 0000 turn RD5 Led
                break;
                
            case 0x0D:  // if RC1 is pressed = 1101 0000  - RC1 goes from pull up high 1 to low 0
                PORTD = 0x08;  // 0000 1000 turn RD3 Led
                break;
                
            case 0x0B:  // if RC2 is pressed = 1100 0000  - RC2 goes from pull up high 1 to low 0
                PORTD = 0x28;  // 0010 1000 turn on RD3 AND RD5 LED
                break;
                
            case 0x07:  // if RC3 is pressed = 0111 0000  - RC3 goes from pull up high 1 to low 0
                PORTD = 0x00;  // 0000 0000 turn off RD3 and RD5 led
                break;

            default:
                PORTD = 0x00;
                break;
        }
        
    }
}