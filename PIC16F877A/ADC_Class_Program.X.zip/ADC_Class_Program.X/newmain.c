/*
 * File:   newmain.c
 * Author: vignesh-camkie
 *
 * Created on 1 May, 2025, 6:19 PM
 */

// PIC16F877A Configuration Bit Settings

// 'C' source line config statements

// CONFIG
#pragma config FOSC = EXTRC     // Oscillator Selection bits (RC oscillator)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config BOREN = OFF      // Brown-out Reset Enable bit (BOR disabled)
#pragma config LVP = OFF        // Low-Voltage (Single-Supply) In-Circuit Serial Programming Enable bit (RB3 is digital I/O, HV on MCLR must be used for programming)
#pragma config CPD = OFF        // Data EEPROM Memory Code Protection bit (Data EEPROM code protection off)
#pragma config WRT = OFF        // Flash Program Memory Write Enable bits (Write protection off; all program memory may be written to by EECON control)
#pragma config CP = OFF         // Flash Program Memory Code Protection bit (Code protection off)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#include <xc.h>
#define _XTAL_FREQ 6000000                  // freq 6MHz

void adc_lcd_init();                        // adc_lcd_init function with no argument and return type
void lcd_number_convert(unsigned int i);    // lcd_number_convert function with unsigned int i as argument and void return type
void lcd_command(unsigned char);            // lcd_command function with unsigned char as argument and void return type
void lcd_data(unsigned char);               // lcd_data function with unsigned char as argument and void return type

unsigned int adc_calibrated_data, adc_volt, adc_high, adc_low;  // unsigned int variables         

void main()                                 // main function starts
{
    adc_lcd_init();                         // calls adc_lcd_init function without any argument
    while(1)                                // while (1) to run continously
    {
        // ADCON0 = 0x81 -> 1000 0001
        //          0x04 -> 0000 0100
        // ADCON0 = 0x85 -> 1000 0101
        ADCON0 |= 0x04;      
        // now ADCON0 = 0x85, ADCON0 & 0x04
        // ADCON0 =  1000 0101
        // 0x04   =  0000 0100
        // Wait for conversion to complete
        while (ADCON0 & 0x04);                          // Polling the GO/DONE bit 2
        adc_high = ADRESH;                              // stores bit 8-9
        adc_low = ADRESL;                               // stores bit 0-7
        adc_volt = (adc_high << 8) + adc_low;           // join this two to make 10bit adc value
        adc_calibrated_data = (adc_volt * 48) / 1024;   // (adc_value x scaled limit) / adc_resolution 
        lcd_number_convert(adc_calibrated_data);
    }
}

void lcd_number_convert(unsigned int i)  // lcd_number_convert function definition takes parameter unsigned int i and void return type
{
    int j = 1, s;                   // int type variable j=1 and s
    unsigned int m;                 // unsigned int variable m
    unsigned char k[5];             // Array to store individual digits
    m = i;                          // store value of i in m variable
    
    while (m != 0)                  
    {
        s = (m - ((m / 10) * 10));  // extract last digit
        k[j] = s;                   // store digit in array
        j++;                        // increment j
        m = m / 10;                 // remove last digit
    }
    k[j] = '\0';
    j--;                            // decrement j
    
    if(k[2] > 0)                    // for 2 digit numbers
    {
        lcd_command(0x80);          // lcd 1st row, 1st column address
        lcd_data(0x30 + k[2]);      // show tens digit
        lcd_command(0x81);          // lcd 1st row, 2nd column address
        lcd_data(0x30 + k[1]);      // show unit digit
    }
    else                            // for 1 digit numbers        
    {
        lcd_command(0x80);          // lcd 1st row, 1st column address
        lcd_data(0x20);             // prints space
        lcd_command(0x81);          // lcd 1st row, 2nd column address
        lcd_data(0x30 + k[1]);      // show unit digit
    }
    lcd_command(0x82);              // moves to lcd 1st row, 3nd column address
    lcd_data(0x76);                 // Display v character
}

void adc_lcd_init()
{
    TRISC = 0x00;       // set port C as output
    TRISD = 0x00;       // set port D as output
    PORTD = 0x00;
    PORTC = 0x00;
    
    lcd_command(0x30);
    __delay_ms(100);
    lcd_command(0x30);
    __delay_ms(100);
    lcd_command(0x30);
    __delay_ms(100);
    lcd_command(0x38);  // 8 bit mode, 2 lines
    __delay_ms(100);    
    lcd_command(0x06);  // cursor right swift
    __delay_ms(100);
    lcd_command(0x0C);  // display on, cursor off
    __delay_ms(100);
    lcd_command(0x01);  // clear display
    __delay_ms(100);
    
    // ADC initialization
    
    // bit 0-3 = A/D Port config control bits, AN0 channel is used -> 1110 = E
    // bit 6 = A/D Conversion Clock selection bit  -> 1000
    // bit 7 = result format select bit => 1-right justified , 0-left justified
    ADCON1 = 0x8E;      // 1000 1110
    // bit 0 = A/D On bit -> 1
    // bit 1 = Unimplemented -> 0
    // bit 2 = GO/DONE A/D Conversion Status bit  -> 1
    // bit 3-5 = Analog Channel Select bits -> 000 = Channel 0 (AN0)
    // bit 6-7 = A/D Conversion Clock Select bits -> 10 = FOSC/32
    ADCON0 = 0x81;      // 1000 0001
    __delay_ms(100);     // acquisition time
}

void lcd_command(unsigned char cmd) // lcd_command function definition takes parameter unsigned char cmd and void return type
{
    PORTC &= ~0x08;     // RS = 0 (command) 
    PORTD = cmd;        // store value of cmd in PORT D
    PORTC |= 0x01;      // EN = 1
    PORTC &= ~0x01;     // EN = 0 
    __delay_ms(100);    // delay 100ms
}

void lcd_data(unsigned char data)   // lcd_data function definition takes parameter unsigned char data and void return type
{
    PORTC |= 0x08;      // RS = 1 for data
    PORTD = data;       // store value of data in PORT D
    PORTC |= 0x01;      // EN = 1 at RC0
    PORTC &= ~0x01;     // EN = 0 at RC0
    __delay_ms(100);    // delay 100 ms
}