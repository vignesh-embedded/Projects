/*
 * File:   newmain.c
 * Author: vignesh-camkie
 *
 * Created on 25 February, 2025, 9:28 PM
 */

// PIC16F877A Configuration Bit Settings

// 'C' source line config statements

// CONFIG
#pragma config FOSC = EXTRC     // Oscillator Selection bits (RC oscillator)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config BOREN = OFF      // Brown-out Reset Enable bit (BOR disabled)
#pragma config LVP = OFF        // Low-Voltage (Single-Supply) In-Circuit Serial Programming Enable bit (RB3 is digital I/O, HV on MCLR must be used for programming)
#pragma config CPD = OFF        // Data EEPROM Memory Code Protection bit (Data EEPROM code protection off)
#pragma config WRT = OFF        // Flash Program Memory Write Enable bits (Write protection off; all program memory may be written to by EECON control)
#pragma config CP = OFF         // Flash Program Memory Code Protection bit (Code protection off)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#include <xc.h>
#define _XTAL_FREQ 6000000

unsigned char value;
void main()
{
    TRISB = 0xF0;  // RB4-RB7 input & RB0-RB3 output/don't care here  1111 0000
    TRISC = 0x00;  // RC0-RC7 is set as output - but we use only RC1 & RC6
    
    PORTB = 0x00;  // 0000 0000
    PORTC = 0x00;  // 0000 0000
    
    while(1)
    {
        value = PORTB;  // store data of PORTB in value
        
        switch(value)   
        {
            case 0xE0:  // if RB4 is pressed = 1110 0000  - RB4 goes from pull up high 1 to low 0
                PORTC = 0x02;  // 0000 0010 turn RC1 Led
                break;
                
            case 0xD0:  // if RB5 is pressed = 1101 0000  - RB5 goes from pull up high 1 to low 0
                PORTC = 0x42;  // 0100 0010 turn RC1 and RC6 Led
                break;
                
            case 0xB0:  // if RB6 is pressed = 1011 0000  - RB6 goes from pull up high 1 to low 0
                PORTC = 0x40;  // 0100 0000 turn on RC6
                break;
                
            case 0x70:  // if RB7 is pressed = 0111 0000  - RB7 goes from pull up high 1 to low 0
                PORTC = 0x00;  // 0000 0000 turn off RC1 and RC6 led
                break;

            default:
                PORTC = 0x00;
                break;
        }
        
    }
}