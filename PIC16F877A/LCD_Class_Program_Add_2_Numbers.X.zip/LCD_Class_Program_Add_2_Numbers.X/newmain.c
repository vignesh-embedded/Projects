
// PIC16F877A Configuration Bit Settings

// 'C' source line config statements

// CONFIG
#pragma config FOSC = EXTRC     // Oscillator Selection bits (RC oscillator)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config BOREN = ON       // Brown-out Reset Enable bit (BOR enabled)
#pragma config LVP = OFF        // Low-Voltage (Single-Supply) In-Circuit Serial Programming Enable bit (RB3 is digital I/O, HV on MCLR must be used for programming)
#pragma config CPD = OFF        // Data EEPROM Memory Code Protection bit (Data EEPROM code protection off)
#pragma config WRT = OFF        // Flash Program Memory Write Enable bits (Write protection off; all program memory may be written to by EECON control)
#pragma config CP = OFF         // Flash Program Memory Code Protection bit (Code protection off)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#include <xc.h>
#define _XTAL_FREQ 6000000 // 6MHz crystal frequency
//function declations
void init(void);                    // inti function declaration without argument & without return type
void Lcd_Command(unsigned char);    // Lcd_command function declaration with unsigned char argument & without return type
void Lcd_Data(unsigned char);       // Lcd_data function declaration with unsigned char argument & without return type
void delay(unsigned int);           // delay function declaration with unsigned int argument & without return type
void LcdOutput(unsigned int);       // LcdOutput function declaration with unsigned int argument & without return type
// global variables
unsigned char j,k[5],Equal,Plus;    // unsigned char as it require only 0-255
unsigned int num1,num2,sum,delaycount,m,n;  // unsigned int as to store value more than 255

void main()                         // main fuction enters
{
    init();                         // call init function without ANY argument
    num1 = 423;                     // STORE 423 in num1 variable
    num2 = 500;                     // STORE 500 in num2 variable
    Equal = '=';                    // '=' char ASCII value for decimal is 61, we can use that also
    Plus = '+';                     // '+' char ASCII value in decimal is 43
    Lcd_Command(0x80);    // Lcd_Command function is called with (0x80) - Set cursor position for LCD - It sets 1st Row 1st Box
    LcdOutput(num1);      // Lcd_Output function is called with num1 value, num1 = 423
    Lcd_Command(0x83);    // Set cursor position
    Lcd_Data(Plus);       // Display '+'
    Lcd_Command(0x84);    // Set cursor position
    LcdOutput(num2);      // Display second number
    Lcd_Command(0x87);    // Set cursor position
    Lcd_Data(Equal);      // Display '='
    Lcd_Command(0x88);    // Set cursor position
    sum = num1 + num2;
    LcdOutput(sum);       // Display sum
    
    while(1);             // Infinite loop
}

void init(void)
{
    TRISC = 0x00;         // Set PORTC as output
    TRISD = 0x00;         // Set PORTD as output

    Lcd_Command(0x30);
    delay(100);
    Lcd_Command(0x30);
    delay(100);
    Lcd_Command(0x30);
    delay(100);
    Lcd_Command(0x38);    // 8-bit mode, 2 lines
    delay(100);
    Lcd_Command(0x06);    // Cursor right shift
    delay(100);
    Lcd_Command(0x0C);    // Display on, cursor off
    delay(100);
    Lcd_Command(0x01);    // Clear display
    delay(100);
}

void LcdOutput(unsigned int i)  // Lcd_Output function Definition takes parameter unsigned int i
{
    unsigned char s, j=1;       // local variable j,s
    m = i;                      // m is global variable, store i value in m
    while(m != 0)               // check condition m is not eqaul to 0, here (423!= 0) so, condition TRUE 1
    {
        s = m-((m/10)*10);      // m=423, m/10 = 42, 42*10= 420, 423-420=3 // store 3 in s
        k[j] = s;               // in array k of j assign value of s k[1]=3
        j++;                    // increment j, j = 2
        m = m/10;               // 423/10 = 42, m=42, again while condition is checked till it become false 0 , when 4/10 =0 fail
    }
    k[j] = '\0';                // array k = { 324'\0'}        
    j=j-1;                      // j=4, j-1 = 3
    while(j!=0)                 // check condition j!=0,  j=3, 3!=0
    {
        n = 0x30 + k[j];        // 0x30 ASCII 0, 48+4 = 52, char for 4
        Lcd_Data(n);            // Call Lcd_Data function with n as argument
        j--;                    // j value is decremented  
    }
}

void Lcd_Command(unsigned char i)       // Lcd_command function Definition takes parameter unsigned char i
{
    PORTC &= ~0x08;        // RC3 = RS, RS=0 for command 
    //Use AND & bitwise operator to clear bit at position RC0 without affecting other bits 
    //  ~0x08  = 1111 0110
    //  PORTC  = 0000 0000
    //  OUTPUT = 0000 0000
    PORTD = i;             // store value of i in PORTD
    
    PORTC |= 0x01;         // EN=1 at RC0 
    //Use OR | bitwise operator to set bit at position RC0 without affecting other bits 
    //  PORTC  = 0000 0000
    //  MASK   = 0000 0001
    //  OUTPUT = 0000 0001
    
    PORTC &= ~0x01;        // EN=0 at RC0    
    //Use AND & bitwise operator to clear bit at position RC0 without affecting other bits 
    //  PORTC   = 0000 0001
    //  Mask = 1111 1110 
    //  OUTPUT  = 0000 0000
    __delay_ms(100);
}

void Lcd_Data(unsigned char i)      // Lcd_Data function Definition takes parameter unsigned char i
{
    PORTC |= 0x08;         // RS=1 at RC3, OR to set 1
    PORTD = i;             // store value of i in PORTD
    PORTC |= 0x01;         // EN=1 at RC0
    PORTC &= ~0x01;        // EN=0 at RC0
    __delay_ms(100); 
}

void delay(unsigned int delaycount)
{
    while(--delaycount);   // delay loop
}