
// PIC16F877A Configuration Bit Settings

// 'C' source line config statements

// CONFIG
#pragma config FOSC = EXTRC     // Oscillator Selection bits (RC oscillator)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config BOREN = OFF      // Brown-out Reset Enable bit (BOR disabled)
#pragma config LVP = OFF         // Low-Voltage (Single-Supply) In-Circuit Serial Programming Enable bit (RB3/PGM pin has PGM function; low-voltage programming enabled)
#pragma config CPD = OFF        // Data EEPROM Memory Code Protection bit (Data EEPROM code protection off)
#pragma config WRT = OFF        // Flash Program Memory Write Enable bits (Write protection off; all program memory may be written to by EECON control)
#pragma config CP = OFF         // Flash Program Memory Code Protection bit (Code protection off)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#include <xc.h>
#define _XTAL_FREQ 6000000 // 6MHz 

// Function Declarations

void Lcd_Data(unsigned char);           // Lcd_Data function with argument unsigned char (0-255) and no return type
void Lcd_Command(unsigned char);        // Lcd_Command function with argument unsigned char (0-255) and no return type
void Lcdoutput(unsigned int);           // Lcdoutput function with argument unsigned char (0-255) and no return type
void keyscane(void);                    // keyscane function with no argument and return type
void init(void);                        // init function with no argument and return type

unsigned char array[15] = "SET SPD:    RPM";  // unsigned char array to store 15 elements including spaces (compile time array)
unsigned char x,value;                        // unsigned char variables x (for loop), value (0-255)
unsigned int i,j,d1,d2,d3,d4;                 // unsigned int variables i,j,d1,d2,d3,d4

void main()     // call main function with no argument and return type                            
{
    init();     // call init function with no argument
    while(1)    // while loop runs forever
    {
        keyscane(); // calls keyscane function with no arguments 
    }
}

void init()     // init function definition
{
    TRISC = 0x00;    // PORTC as output
    TRISD = 0x00;    // PORTD as output
    TRISB = 0xF0;    // RB4-RB7 as input, RB0-RB3 as output
    
    OPTION_REG &= 0x7F; // OPTION REGISTER Internal Pull Up Register on PORTB / bit 7 - 0 Enable, 1 Disable
    
    Lcd_Command(0x30); 
    __delay_ms(100);
    Lcd_Command(0x30);
    __delay_ms(100);
    Lcd_Command(0x38);  // 8-bit mode, 2 lines
    __delay_ms(100);    
    Lcd_Command(0x06);  // Cursor increment
    __delay_ms(100);
    Lcd_Command(0x0C);  // Display ON, cursor OFF
    __delay_ms(100);
    Lcd_Command(0x01);  // Clear display
    __delay_ms(100);    
}

void keyscane()  // keyscane function definition with no argument and return type
{
    value = PORTB & 0xF0;  // Mask = 0xF0 with PORTB to get only RB4 to RB7 and keep RB0-RB3 to 0, to match the switch case 
    switch(value)          
    {
        case 0xE0:                          // If RB4 is Pressed, 0xE0 = 1110 0000
            Lcd_Command(0x80);              // Set the LCD Address to 0x80 position
            for(x = 0; x < 8; x++)          // for loop to print SET SPD: for array
            {
                Lcd_Data(array[x]);         
            }
            Lcd_Command(0x8C);              // Set the LCD Address to 0x8C position
            for(x = 12; x < 15; x++)        // for loop to print 4 spaces for array
            {
                Lcd_Data(array[x]);
            }
            Lcd_Command(0x88);              // Set the LCD Address to 0x88 position
            Lcdoutput(j);                   // to print value which is present in j
            break;          

        case 0xD0:                          // If RB5 is Pressed, 0xD0 = 1101 0000
            j++;                            // increment j value
            if(j > 5000)                    // checks condition with limit j should not exceed j>5000
            {
                j=5000;                     // if exceeded set j=5000
            }
                Lcd_Command(0x88);              // calls Lcd_Command function with argument (0x88) to set address in LCD
            Lcdoutput(j);                   
            break;

        case 0xB0:                          // If RB6 is Pressed, 0xB0 = 1011 0000
            j--;                            // decrement j value
            if(j < 1)                       // check if j is less than 1 
            {   
                j=1;                        // if true set j = 1
            }
            Lcd_Command(0x88);              // calls Lcd_Command function with argument (0x88) to set address in LCD
            Lcdoutput(j);                   // calls Lcdoutput function with current value of j as argument
            break;
            
        case 0x70:                          // If RB7 is Pressed, 0x70 = 0111 0000
            j = 0;                          // set j=0 to reset value
            Lcd_Command(0x88);              // calls Lcd_Command function with argument (0x88) to set address in LCD
            Lcdoutput(j);                   // calls Lcdoutput function with current value of j as argument
            break;                          
    }
}

void Lcd_Command(unsigned char i)           // Lcd_Command function definition with unsigned char parameter i and no return type
{
    PORTC &= ~0x08;    // RS = 0 (command)
    PORTD = i;         // store value of i in PORTD
    PORTC |= 0x01;     // EN = 1
    __delay_ms(100);   // delay 100 ms
    PORTC &= ~0x01;    // EN = 0
    __delay_ms(100);   // delay 100 ms
}

void Lcd_Data(unsigned char i)          // Lcd_Data function definition with unsigned char parameter i and no return type
{
    PORTC |= 0x08;     // RS = 1 (data)
    PORTD = i;         // store value of i in PORTD
    PORTC |= 0x01;     // EN = 1
    __delay_ms(100);     // delay 100 ms
    PORTC &= ~0x01;    // EN = 0
    __delay_ms(100);   // delay 100 ms
}

void Lcdoutput(unsigned int i)          // Lcdoutput function definition with unsigned int parameter i and no return type
{
    d4 = (unsigned char)(i/1000);               // extract Thousands digit and store in d4
    d3 = (unsigned char)((i % 1000)/100);       // extract Hundreds digit and store in d3
    d2 = (unsigned char)((i % 100)/10);         // extract Tens digit and store in d2
    d1 = (unsigned char)(i % 10);               // extract Units digit and store in d1
    
    // Convert to ASCII, 0x30 = '0' decimal(48) and add value of d
    
    Lcd_Data(0x30 + d4);                   // Display Thousands digit
    Lcd_Data(0x30 + d3);                   // Display Hundreds digit
    Lcd_Data(0x30 + d2);                   // Display Tens digit
    Lcd_Data(0x30 + d1);                   // Display Ones digit
}
