
// PIC16F877A Configuration Bit Settings

// 'C' source line config statements

// CONFIG
#pragma config FOSC = EXTRC     // Oscillator Selection bits (RC oscillator)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config BOREN = OFF      // Brown-out Reset Enable bit (BOR disabled)
#pragma config LVP = OFF        // Low-Voltage (Single-Supply) In-Circuit Serial Programming Enable bit (RB3 is digital I/O, HV on MCLR must be used for programming)
#pragma config CPD = OFF        // Data EEPROM Memory Code Protection bit (Data EEPROM code protection off)
#pragma config WRT = OFF        // Flash Program Memory Write Enable bits (Write protection off; all program memory may be written to by EECON control)
#pragma config CP = OFF         // Flash Program Memory Code Protection bit (Code protection off)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#include <xc.h>                                     // header file
#define _XTAL_FREQ 6000000                          // 6mhz freq
#define ADC_Range 1023                              // adc maximum range for 10bit adc

// function prototypes
void init(void);                                    // init function declartion without any argument & return type
void Lcd_Command(unsigned char);                    // Lcd_Cmmand function declartion with unsigned char as parameter and void return type
void Lcd_Data(unsigned char);                       // Lcd_Data function declartion with unsigned char as parameter and void return type
void Lcd_Output(unsigned int, unsigned char);       // Lcd_Output function declartion with 2 parameters unsigned int & char and void return type

unsigned char msg1[16] = "CH1 DATA: ";              // unsigned char msg array to display channel 1 raw data
unsigned char msg2[16] = "CH4 DATA: ";              // unsigned char msg array to display channel 4 calibrated data

unsigned int adc_low, adc_high, result, volt, i;    // unsigned int variables declarations            

void main()                                         // main function starts
{
    init();                                         // CallS init function 
    
    Lcd_Command(0x80);                              // lcd address 1st row, 1st column
    for(i = 0; i < 9; i++)                          // for loop to display first 9 characters of msg1
        Lcd_Data(msg1[i]);             
    
    Lcd_Command(0xC0);                              // lcd address 2nd row, 1st column
    for(i = 0; i < 9; i++)                          // for loop to display first 9 characters of msg2
        Lcd_Data(msg2[i]);     
    
    while(1)                                        // while infinite loop
    {
        ADCON0 = 0x89;                              // 1000 1001
        __delay_ms(100);                            // acquisition delay 100ms
        ADCON0 |= 0x04;                             // start adc conversion
        while (ADCON0 & 0x04);                      // wait until conversion is complete
        adc_high = ADRESH;                          // store high byte in adc_hign
        adc_low = ADRESL;                           // store low byte in adc_low
        result = (adc_high << 8) + adc_low;         // join high and low bytes for 10 bit result
        
        Lcd_Command(0x8A);                          // set lcd address for raw data in  line 1
        Lcd_Output(result, 0);                      // call lcd_output function to show raw data
        Lcd_Data('V');                              // display 'V'
        

        ADCON0 = 0xA1;                              // 1010 0001
        __delay_ms(100);                            // acquisition delay 100ms
        ADCON0 |= 0x04;                             // start adc conversion
        while (ADCON0 & 0x04);                      // wait until conversion is complete
        adc_high = ADRESH;                          // store high byte in adc_hign
        adc_low = ADRESL;                           // store low byte in adc_low
        result = (adc_high << 8) + adc_low;         // join high and low bytes for 10 bit result
        volt = ((unsigned long)result * 135) / ADC_Range; // do calibration for range 0 to 135
        
        Lcd_Command(0xCA);                          // set lcd address for calibrated data in  line 2
        Lcd_Output(volt, 1);                        // call lcd_output function to show calibrated data
        Lcd_Data('V');                              // display 'V'
    }
}

void init(void)
{
    TRISC = 0x00;              // set PORTC to output
    TRISD = 0x00;              // set PORTD to output
    PORTC = 0x00;             
    PORTD = 0x00;              
    
    // bit 3-0 = PCFG3:PCFG0: A/D Port Configuration Control bits
    // 0000 -> AN1 & AN4 to use for analog
    // bit 5-4 Unimplemented -> 0
    // bit 6 = ADCS2: A/D Conversion Clock Select bit -> 0
    // bit 7 = ADFM: A/D Result Format Select bit -> 1 = Right justified 
    ADCON1 = 0x80;             // 1000 0000
    
    // bit 0 = ADON: A/D On bit -> 1 for power on
    // bit 1 = unimplemented
    // bit 2 = GO/DONE: A/D Conversion Status bit, initialy 0
    // bit 3-5 = CHS2:CHS0: Analog Channel Select bits
    // bit 6-7 = ADCS1:ADCS0: A/D Conversion Clock Select bits, FOSC/32 -> 10
    ADCON0 = 0x81;             
    __delay_ms(100);           // acquisition delay for adc
    
    Lcd_Command(0x30);
    __delay_ms(100);
    Lcd_Command(0x30);
    __delay_ms(100);
    Lcd_Command(0x30);
    __delay_ms(100);
    Lcd_Command(0x38);  // 8 bit mode, 2 lines
    __delay_ms(100);    
    Lcd_Command(0x06);  // cursor right swift
    __delay_ms(100);
    Lcd_Command(0x0C);  // display on, cursor off
    __delay_ms(100);
    Lcd_Command(0x01);  // clear display
    __delay_ms(100);
}

void Lcd_Output(unsigned int i, unsigned char cali)  // Lcd_Output function definition it takes 2 parameters 
{
    unsigned int m = i;                              // Store i in m
    unsigned char k[5];                              // store digits in char array
    int j = 0;                                       // j=0
    int digits = (cali) ? 3 : 4;                     // check condition for 3 or 4 digit

    while (m > 0)                                    // while m greater than 0
    {        
            k[j] = (m % 10) + '0';                   // extract digits and store in k array with ASCII convert
            m /= 10;                                 // Remove  digit
            j++;                                     // increment j
        }

    for (j = digits - 1; j >= 0; j--) {             // for loop to display digits
        Lcd_Data(k[j]);                            
    }
}

void Lcd_Data(unsigned char i)          // lcd_data function definition takes parameter unsigned char i and void return type 
{
    PORTC |= 0x08;                      // RS = 1 for data
    PORTD = i;                          // store value of i in PORT D
    PORTC |= 0x01;                      // EN = 1 at RC0
    PORTC &= ~0x01;                     // EN = 0 at RC0
    __delay_ms(100);                    // delay 100 ms
}

void Lcd_Command(unsigned char i)       // lcd_command function definition takes parameter unsigned char i and void return type
{
    PORTC &= ~0x08;                     // RS = 0 (command) 
    PORTD = i;                          // store value i in PORT D
    PORTC |= 0x01;                      // EN = 1
    PORTC &= ~0x01;                     // EN = 0 
    __delay_ms(100);                    // delay 100 ms
}