
// PIC16F877A Configuration Bit Settings

// 'C' source line config statements

// CONFIG
#pragma config FOSC = EXTRC     // Oscillator Selection bits (RC oscillator)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config BOREN = OFF      // Brown-out Reset Enable bit (BOR disabled)
#pragma config LVP = OFF        // Low-Voltage (Single-Supply) In-Circuit Serial Programming Enable bit (RB3 is digital I/O, HV on MCLR must be used for programming)
#pragma config CPD = OFF        // Data EEPROM Memory Code Protection bit (Data EEPROM code protection off)
#pragma config WRT = OFF        // Flash Program Memory Write Enable bits (Write protection off; all program memory may be written to by EECON control)
#pragma config CP = OFF         // Flash Program Memory Code Protection bit (Code protection off)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#include <xc.h>
#define _XTAL_FREQ 6000000      // Oscillator freq 6MHz

// Function declarations
void init(void);                // init function with no argument and return type
void Lcd_Command(unsigned char);// Lcd_Command function with unsigned char argument
void Lcd_Data(unsigned char);   // Lcd_Data function with unsigned char argument
void LcdOutput(int);            // LcdOutput function with int argument

// Global variables
unsigned char j,k[5],Equal,Plus,Minus;  // unsigned char variables j,Equal, Plus, Minus, k[5] array 
int num1,num2,diff;           // integer variables num1,num2,diff
unsigned int m,n;   // unsigned int variables delaycount,m,n
unsigned char sign_find = 0;  // unsigned char variable sign_find

void main()                 // main function definition with no argument and return type
{
    init();                     // call init function
    //num1 = 200;               // store 200 in num1
    //num2 = 100;               // store 100 in num2
    num1 = 100;                 // store 100 in num1
    num2 = 200;                 // store 200 in num2
    Equal = '=';                // store = char in Equal
    Plus = '+';                 // store + char in Plus
    Minus = '-';                // store - char in Minus
    
    Lcd_Command(0x80);          // Set Address 0x80 to row 1/col 1 in LCD
    LcdOutput(num1);            // num1 is passed as argument to LcdOutput function
    Lcd_Data(Minus);            // '-' character is passed as argument to Lcd_Data
    LcdOutput(num2);            // num2 is passed as argument to LcdOutput function
    Lcd_Data(Equal);            // '=' character is passed as argument to Lcd_Data
    Lcd_Command(0x88);          // Set Address 0x88 to row 1/col 9 in LCD
    diff = num1 - num2;         // sub num1-num2 and store in diff variable
    LcdOutput(diff);            // Display diff result
    
    while(1);                   // Infinite while loop
}

void init(void)                 // init function definition
{
    TRISC = 0x00;               // PORTC as output
    TRISD = 0x00;               // PORTD as output

    Lcd_Command(0x30);          // call Lcd_command with 0x30 as argument
    __delay_ms(100);            // Delay 100ms
    Lcd_Command(0x30);          // call Lcd_command with 0x30 as argument
    __delay_ms(100);            // Delay 100ms
    Lcd_Command(0x30);          // call Lcd_command with 0x30 as argument
    __delay_ms(100);            // Delay 100ms
    Lcd_Command(0x38);          // 8-bit mode, 2 lines display
    __delay_ms(100);            // Delay 100ms
    Lcd_Command(0x06);          // right shift 
    __delay_ms(100);            // Delay 100ms
    Lcd_Command(0x0C);          // display on, cursor off
    __delay_ms(100);            // Delay 100ms
    Lcd_Command(0x01);          // Clear display
    __delay_ms(100);            // Delay 100ms
}

void LcdOutput(int i)           // LcdOutput function definition with int parameter
{
    j = 0;                      // unsigned char j (global variable) 
    m = (i < 0) ? -i : i;       // ternary operator checks condition if i<0, TRUE=-i, FALSE=i
    
    if (sign_find == 0x88) 
    { 
        if (i < 0)      // if num is negative
        {           
            Lcd_Data('-');      // send '-' to Lcd_data
        } 
        else if (i > 0)         // if num is pos
        {    
            Lcd_Data('+');      // send '+' to Lcd_data
        }
    }
    while (m != 0) 
    {            // while checks if m!=0 , ex: 200 200!=0(TRUE) 
            k[j] = m % 10;      // 200 % 10 = 0 is stored in array k[0] since j=0 (at first)
            j++;                // Increment j
            m /= 10;            // 200 /10 = 20  => m = 20 => loop continus till m become 0
        }
    while (j > 0)               // While there are digits to display
    {
        j--;                    // Decrement j
        n = 0x30 + k[j];        // 0x30 => 0 in ASCII , 48(decimal), Add with array k[] value
        Lcd_Data(n);            // send n to lcd_data as argument
    }
}

void Lcd_Command(unsigned char i) // Lcd_Command function definition
{
    PORTC &= ~0x08;             // RS=0  - command
    PORTD = i;                  // Store i in PORTD
    PORTC |= 0x01;              // EN=1
    __delay_ms(100);            // delay 100 ms
    PORTC &= ~0x01;             // EN=0 
    __delay_ms(100);            // delay  100 ms
    sign_find = i;           // Store i in last_command
}

void Lcd_Data(unsigned char i)  // Lcd_Data function definition
{
    PORTC |= 0x08;              // RS=1 - data 
    PORTD = i;                  // Store i in PORTD
    PORTC |= 0x01;              // EN=1 
    __delay_ms(100);            // delay 100 ms
    PORTC &= ~0x01;             // EN=0
    __delay_ms(100);            // delay 100 ms
}
