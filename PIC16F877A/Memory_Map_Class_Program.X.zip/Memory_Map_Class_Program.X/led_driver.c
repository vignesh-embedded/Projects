#include <xc.h>

void led_init(void)
{
    TRISC = 0x00;
    PORTC = 0x00;
}

void all_led_on(void)
{
    PORTC = 0xFF;
}

void led_particular_pin_on(unsigned char pin_number)
{
    PORTC |= (1<<pin_number);
}

void led_off(void)
{
    PORTC = 0x00;
}