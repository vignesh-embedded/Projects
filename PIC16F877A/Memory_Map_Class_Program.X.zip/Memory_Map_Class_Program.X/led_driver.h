#ifndef __LED_DRIVER_H
#define __LED_DRIVER_H

void led_init(void);
void all_led_on(void);
void led_particular_pin_on(unsigned char pin_number);
void led_off(void);

#endif