#pragma config FOSC = EXTRC     // Select External RC oscillator for the clock
#pragma config WDTE = OFF       // Disable Watchdog Timer
#pragma config PWRTE = OFF      // Disable Power-up Timer
#pragma config BOREN = OFF      // Disable Brown-out Reset
#pragma config LVP = OFF        // Disable Low-Voltage Programming (RB3 is used as a digital I/O pin)
#pragma config CPD = OFF        // Disable code protection for Data EEPROM
#pragma config WRT = OFF        // Disable write protection for Flash program memory
#pragma config CP = OFF         // Disable code protection for Flash program memory
#include <xc.h>
#define _XTAL_FREQ 6000000 

// Define keypad row pins connected to PORTB
#define R1 RB0  // Row 1
#define R2 RB1  // Row 2
#define R3 RB2  // Row 3
#define R4 RB3  // Row 4

// Define keypad column pins connected to PORTB
#define C1 RB4  // Column 1
#define C2 RB5  // Column 2
#define C3 RB6  // Column 3
#define C4 RB7  // Column 4

// Function declarations
void lcd_init();             // Function to initialize the LCD
void show(unsigned char *s); // Function to display string on LCD
void Lcd_Command(unsigned char a); // Function to send commands to the LCD
void Lcd_Data(unsigned char b);    // Function to send data to the LCD
unsigned char key_detect();  // Function to detect which key is pressed

// Global variables
unsigned int i, x;  

// 4x4 Keypad layout
unsigned char keypad[4][4] = {{'7','8','9','/'}, {'4','5','6','*'}, {'1','2','3','-'}, {'C','0','=','+'}}; 

// Message to be displayed on the LCD
unsigned char arr[] = {" Enter the Key "}; 

// Row and column locations for pressed key
unsigned char rowloc, colloc; 

void main()
{
    // Initialize LCD
    lcd_init();

    // Set cursor position to the first line
    Lcd_Command(0x80);  

    // Display the message "Enter the Key" on the LCD
    for (x = 0; x < 17; x++) {
        Lcd_Data(arr[x]);
    }

    // Infinite loop to continuously detect and display pressed key
    while (1)
    {
        // Set cursor position to the middle of the second line
        Lcd_Command(0xc7);

        // Detect and display the key pressed on the keypad
        Lcd_Data(key_detect());
    }
}

// Function to initialize the LCD
void lcd_init()
{
    TRISC = 0x00;   // Set PORTC as output for control signals (RS, E)
    PORTC = 0x00;   // Clear PORTC
    TRISD = 0x00;   // Set PORTD as output for data signals
    PORTD = 0x00;   // Clear PORTD
    TRISB = 0xF0;   // Set upper nibble of PORTB (RB4-RB7) as input (columns) and lower nibble (RB0-RB3) as output (rows)
    OPTION_REG &= 0x7F;   // Enable weak pull-ups for PORTB
    // Initialize LCD in 8-bit mode
    Lcd_Command(0x30);  // Send 0x30 (8-bit mode command)
    __delay_ms(100);    // Wait for 100 ms
    Lcd_Command(0x30);  // Send 0x30 again
    __delay_ms(100);    // Wait for 100 ms
    Lcd_Command(0x30);  // Send 0x30 again
    __delay_ms(100);    // Wait for 100 ms
    
    Lcd_Command(0x38);  // Set LCD to 2-line display, 8-bit mode
    __delay_ms(100);    // Wait for 100 ms
    
    Lcd_Command(0x06);  // Set LCD entry mode to increment cursor
    __delay_ms(100);    // Wait for 100 ms
    
    Lcd_Command(0x0C);  // Turn on display, turn off cursor
    __delay_ms(100);    // Wait for 100 ms
    
    Lcd_Command(0x01);  // Clear display
    __delay_ms(100);    // Wait for 100 ms
}

// Function to detect which key is pressed on the keypad
unsigned char key_detect()
{
    PORTB = 0x00;   // Clear PORTB (set all rows to low)
    
    // Wait for a key press (until any column goes low)
    while (C1 && C2 && C3 && C4);  
    
    // Loop until a key press is detected
    while (!C1 || !C2 || !C3 || !C4) {
        R1 = 0;    // Set row 1 low (active low)
        R2 = R3 = R4 = 1;  // Set other rows high
        if (!C1 || !C2 || !C3 || !C4) {
            rowloc = 0;  // Key is in row 1
            break;
        }

        R2 = 0; R1 = 1;  // Set row 2 low, row 1 high
        if (!C1 || !C2 || !C3 || !C4) {
            rowloc = 1;  // Key is in row 2
            break;
        }

        R3 = 0; R2 = 1;  // Set row 3 low, row 2 high
        if (!C1 || !C2 || !C3 || !C4) {
            rowloc = 2;  // Key is in row 3
            break;
        }

        R4 = 0; R3 = 1;  // Set row 4 low, row 3 high
        if (!C1 || !C2 || !C3 || !C4) {
            rowloc = 3;  // Key is in row 4
            break;
        }
    }

    // Detect the column where the key is pressed
    if (C1 == 0 && C2 != 0 && C3 != 0 && C4 != 0)
        colloc = 0;  // Key is in column 1
    else if (C1 != 0 && C2 == 0 && C3 != 0 && C4 != 0)
        colloc = 1;  // Key is in column 2
    else if (C1 != 0 && C2 != 0 && C3 == 0 && C4 != 0)
        colloc = 2;  // Key is in column 3
    else if (C1 != 0 && C2 != 0 && C3 != 0 && C4 == 0)
        colloc = 3;  // Key is in column 4

    // Wait for the key to be released (until all columns go high)
    while (C1 == 0 || C2 == 0 || C3 == 0 || C4 == 0);  

    // Return the character corresponding to the pressed key
    return keypad[rowloc][colloc];
}

// Function to send data to the LCD
void Lcd_Data(unsigned char i) 
{
    PORTC |= 0x02;    // Set RS (Register Select) to 1 for data mode
    PORTD = i;        // Put data on PORTD
    PORTC |= 0x01;    // Set Enable (E) pin high
    PORTC &= ~0x01;   // Set Enable pin low (data latched)
    __delay_ms(100);  // Wait for 100 ms
}

// Function to send commands to the LCD
void Lcd_Command(unsigned char i) 
{
    PORTC &= ~0x02;   // Set RS (Register Select) to 0 for command mode
    PORTD = i;        // Put command on PORTD
    PORTC |= 0x01;    // Set Enable (E) pin high
    PORTC &= ~0x01;   // Set Enable pin low (command latched)
    __delay_ms(100);  // Wait for 100 ms
}