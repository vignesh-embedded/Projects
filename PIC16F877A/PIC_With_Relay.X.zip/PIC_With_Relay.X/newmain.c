//// PIC16F877A Configuration Bit Settings
//#pragma config FOSC = EXTRC     // RC oscillator
//#pragma config WDTE = OFF       // Watchdog Timer disabled
//#pragma config PWRTE = OFF      // Power-up Timer disabled
//#pragma config BOREN = ON       // Brown-out Reset enabled
//#pragma config LVP = OFF        // Low-Voltage Programming off
//#pragma config CPD = OFF        // Data EEPROM code protection off
//#pragma config WRT = OFF        // Flash write protection off
//#pragma config CP = OFF         // Flash code protection off
//
//#include <xc.h>
//#define _XTAL_FREQ 6000000 // 6MHz crystal frequency
//
//// Function declarations
//void init(void);
//void Lcd_Command(unsigned char);
//void Lcd_Data(unsigned char);
//void delay(unsigned int);
//void LcdOutput(int);
//
//// Global variables
//unsigned char j, k[6], Equal, Plus, Minus;
//int num1, num2, diff;
//unsigned int delaycount, m, n;
//
//void main(void)
//{
//    init();
//    num1 = 200;         // Changed for debugging based on your output
//    num2 = 100;         // Adjust these to your test case (e.g., 200 and 100)
//    
//    Equal = '=';
//    Plus = '+';
//    Minus = '-';
//    
//    Lcd_Command(0x80);  // 1st row, 1st column
//    LcdOutput(num1); // Display num1 (no sign)
//    
//    Lcd_Command(0x83);  // Move to 4th column
//    Lcd_Data(Minus);    // Display '-'
//    
//    Lcd_Command(0x84);  // Move to 5th column
//    LcdOutput(num2); // Display num2 (no sign)
//    
//    Lcd_Command(0x87);  // Move to 8th column
//    Lcd_Data(Equal);    // Display '='
//    
//    Lcd_Command(0x88);  // Move to 9th column
//    
//    diff = num1 - num2; // Compute difference (200 - 100 = 100)
//    LcdOutput(diff); // Display diff (with sign)
//    
//    while(1);           // Infinite loop
//}
//
//void init(void)
//{
//    TRISC = 0x00;       // PORTC as output
//    TRISD = 0x00;       // PORTD as output
//
//    Lcd_Command(0x30);  // Initialization sequence
//    delay(100);
//    Lcd_Command(0x30);
//    delay(100);
//    Lcd_Command(0x30);
//    delay(100);
//    Lcd_Command(0x38);  // 8-bit mode, 2 lines
//    delay(100);
//    Lcd_Command(0x06);  // Cursor right shift
//    delay(100);
//    Lcd_Command(0x0C);  // Display on, cursor off
//    delay(100);
//    Lcd_Command(0x01);  // Clear display
//    delay(100);
//}
//
//void LcdOutput(int i)
//{
//}
//
//void Lcd_Command(unsigned char i)
//{
//    PORTC &= ~0x08;    // RS=0 for command
//    PORTD = i;         // Send command
//    PORTC |= 0x01;     // EN=1
//    PORTC &= ~0x01;    // EN=0
//    __delay_ms(1);     // Reduced delay (adjust if needed)
//}
//
//void Lcd_Data(unsigned char i)
//{
//    PORTC |= 0x08;     // RS=1 for data
//    PORTD = i;         // Send data
//    PORTC |= 0x01;     // EN=1
//    PORTC &= ~0x01;    // EN=0
//    __delay_ms(1);     // Reduced delay (adjust if needed)
//}
//
//void delay(unsigned int delaycount)
//{
//    while (--delaycount); // Simple delay
//}