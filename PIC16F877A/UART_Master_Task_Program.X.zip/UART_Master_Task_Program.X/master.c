/*
 * File:   master.c
 * Author: vignesh-camkie
 *
 * Created on 23 May, 2025, 4:11 PM
 */

// PIC16F877A Configuration Bit Settings
#pragma config FOSC = EXTRC     // Oscillator Selection bits (RC oscillator)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config BOREN = OFF      // Brown-out Reset Enable bit (BOR disabled)
#pragma config LVP = OFF        // Low-Voltage (Single-Supply) In-Circuit Serial Programming Enable bit (RB3 is digital I/O, HV on MCLR must be used for programming)
#pragma config CPD = OFF        // Data EEPROM Memory Code Protection bit (Data EEPROM code protection off)
#pragma config WRT = OFF        // Flash Program Memory Write Enable bits (Write protection off; all program memory may be written to by EECON control)
#pragma config CP = OFF         // Flash Program Memory Code Protection bit (Code protection off)

#include <xc.h>
#define _XTAL_FREQ 6000000      // 6 MHz Oscillator Freq

// Function prototypes
void init_fun();            
void transmitter();           // function to transmit data
void receiver();              // Function to Receive data

// Global variables
unsigned char value;          // Variable to store button press in PORTB
unsigned char rx_data;        // Variable to store Received data

void main()                   // main function
{
    init_fun();               // calls init function
    while(1)
    {
        transmitter();        // calls transmitter function
        receiver();           // calls receiver function
    }
}

void init_fun()             // init function definition
{
    TRISB = 0xF0;       // RB4 to RB7 as input for push button, 1111 0000
    PORTB = 0x00;       // Clear PORTB 0000 0000   
    OPTION_REG &= 0x7F; // Enable Pull Up in PORTB (bit 7 to 0) => 0111 1111
    
    TRISD = 0x00;       // Configure PORTD as output 0000 0000
    PORTD = 0x00;       // Clear PORTD 0000 0000
    
    // UART Configurations
    TRISC = 0xC0;       // Configure RC6 and RC7 for TX/RX (other bits as output) 1100 0000
    TXSTA = 0x20;       // Transmit Status And Control Register => Enable TXEN bit 5 - 0010 0000
    RCSTA = 0x90;       // Receive Status and Control Register => Enable SPEN & CREN - 1001 0000
    SPBRG = 0x09;       // Baud rate => 9600 - 0000 1001
}

void transmitter()              // Function to send data
{
    value = PORTB;              // Read button press in PORTB continiously 
    switch(value)               // Check with switch case condition
    {
        case 0xE0:              // if RB4 is pressed = 1110 0000
            TXREG = 'A';        // Send A to TXREG
            __delay_ms(100);    // delay 100 ms to avoid switch debounce
            break;
        case 0xD0:              // if RB5 is pressed = 1101 0000
            TXREG = 'B';        // Send B to TXREG
            __delay_ms(100);    // delay 100 ms to avoid switch debounce
            break;
        case 0xB0:              // if RB6 is pressed = 1011 0000
            TXREG = 'C';        // Send C to TXREG
            __delay_ms(100);    // delay 100 ms to avoid switch debounce
            break;
        case 0x70:              // if RB7 is pressed = 0111 0000
            TXREG = 'D';        // Send D to TXREG
            __delay_ms(100);    // delay 100 ms to avoid switch debounce
            break;
    }
}

void receiver()                 // Function to receive data
{
    if(PIR1 & 0x20)             // Check if data is received -> RCIF bit 5 is set
    {
        rx_data = RCREG;        // take received data from RCREG
        switch(rx_data)         // switch case 
        {
            case 'a':           // if 'a' is received
                PORTD = 0x02;   // D1 on (0000 0010)
                break;
            case 'b':           // if 'b' is received
                PORTD = 0x40;   // D6 on (0100 0000)
                break;
            case 'c':           // if 'c' is received
                PORTD = 0x00;   // All LEDs off
                break;
            case 'd':           // if 'd' is received
                PORTD = 0x42;   // D6 and D1 on (0100 0010)
                break;
            default:
                PORTD = 0x00;
        }
    }
}