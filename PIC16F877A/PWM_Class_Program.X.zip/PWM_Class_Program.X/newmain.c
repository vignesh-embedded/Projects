// PIC16F877A Configuration Bit Settings

// 'C' source line config statements

// CONFIG
#pragma config FOSC = EXTRC     // Oscillator Selection bits (RC oscillator)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config BOREN = OFF      // Brown-out Reset Enable bit (BOR disabled)
#pragma config LVP = OFF        // Low-Voltage (Single-Supply) In-Circuit Serial Programming Enable bit (RB3 is digital I/O, HV on MCLR must be used for programming)
#pragma config CPD = OFF        // Data EEPROM Memory Code Protection bit (Data EEPROM code protection off)
#pragma config WRT = OFF        // Flash Program Memory Write Enable bits (Write protection off; all program memory may be written to by EECON control)
#pragma config CP = OFF         // Flash Program Memory Code Protection bit (Code protection off)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#include <xc.h>
#define _XTAL_FREQ 6000000      // 6MHz freq
// Global variables for PWM duty cycles
unsigned char pwm10_high, pwm10_low;    // unsigned char variable to store 10% dutycycle (10 bit) values - high and low
unsigned char pwm50_high, pwm50_low;    // unsigned char variable to store 50% dutycycle (10 bit) values - high and low
unsigned char pwm80_high, pwm80_low;    // unsigned char variable to store 80% dutycycle (10 bit) values - high and low
// Function declarations
void pwm_init(void);                    // pwm_init function with no argument and return type
void pwm_dutycycle_update(void);        // pwm_dutycycle_update function with no argument and return type

void main()                             // main function starts
{
    pwm_init();                         // calls pwm_init function with no arguments
    while(1)                            // Infinite while loop
    {
        pwm_dutycycle_update();         // calls pwm_dutycycle_update inside while loop again and again for 10,50, 80 % dutycycle  
    }
}

void pwm_init(void)                     // pwm_int function definition
{
    TRISC = 0xFB;                       // 1111 1011 = 0xFB, RC2(CCP1) => output
    CCP1CON = 0x0C;                     // 0000 1100 = 0x0C, Configure CCP1 to pwm mode
    PR2 = 0x5E;                         // pwm period register PR2 = 0x5E = 0101 1101
    T2CON = 0x06;                       // timer 2, prescaler 16, 0000 0110 
    pwm10_high = 0x09;                  // 10% dutycycle, 0000 1001
    pwm10_low = 0x02;                   // 10% dutycycle, 0000 0010
    pwm50_high = 0x2F;                  // 50% dutycycle, 0010 1111 
    pwm50_low = 0x00;                   // 50% dutycycle, 0000 0000 
    pwm80_high = 0x48;                  // 80% dutycycle, 0010 1000 
    pwm80_low = 0x00;                   // 80% dutycycle, 0000 0000 
}

void pwm_dutycycle_update(void)         // pwm_dutycycle_update function definition
{
    CCPR1L = pwm10_high;                // store 8 MSB in CCPR1L for 10% dutycycle
    CCP1CON = ((CCP1CON & 0xCF)|(pwm10_low << 4)); // store 2 LSB in CCP1CON 4-5 bit without affecting other bits by & and leftshift and OR them
    __delay_ms(3000);                   // delay 3s
    
    CCPR1L = pwm50_high;                // store 8 MSB in CCPR1L for 50% dutycycle
    CCP1CON = ((CCP1CON & 0xCF)|(pwm50_low << 4)); // store 2 LSB in CCP1CON 4-5 bit without affecting other bits by & and leftshift and OR them
    __delay_ms(3000);                   // delay 3s
    
    CCPR1L = pwm80_high;                // store 8 MSB in CCPR1L for 80% dutycycle
    CCP1CON = ((CCP1CON & 0xCF)|(pwm80_low << 4)); // store 2 LSB in CCP1CON 4-5 bit without affecting other bits by & and leftshift and OR them
    __delay_ms(3000);                   // delay 3s
}